package com.sadia.sadia_shujath

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
